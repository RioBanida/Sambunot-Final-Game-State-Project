playGame = {
	create: function () {
			game.add.sprite(0,0, 'bg');
			
			platforms = game.add.group();
			platforms.enableBody = true;
			
			var ledge = platforms.create(0,560,'grounded'); // nasa pinaka baba
			ledge.body.immovable = true;
			var ledge = platforms.create(50,415,'ground'); // 1 pinaka baba
			ledge.body.immovable = true;
			ledge = platforms.create(290,270,'ground'); // 2
			ledge.body.immovable = true;
			ledge = platforms.create(0,140,'ground'); // 3
			ledge.body.immovable = true;
			ledge = platforms.create(520,415,'ground'); // katapat ng 1
			ledge.body.immovable = true;
			ledge = platforms.create(540,130,'ground'); // katapat ng 3
			ledge.body.immovable = true;
			
			 pause_label = game.add.button(380,10, 'btn_pause');
				pause_label.inputEnabled = true;
				pause_label.fixedToCamera = true;
				pause_label.events.onInputUp.add(function (){
					game.paused = true;
					menu = game.add.sprite(w/2,h/2,'btn_paused');
					menu.anchor.setTo(0.5,0.5);
					choiseLabel = game.add.text (w/2,h-240, 'TAP AGAIN TO UNPAUSE',{fill: 'white'});
					choiseLabel.anchor.setTo(0.5,0.5);
					
					 });
				game.input.onDown.add(unpause,self);
				function unpause(event){
				if(game.paused){
					menu.destroy();
					choiseLabel.destroy();
					
					game.paused = false;
				}
				}
			
	        bgmusic = game.add.audio('bgmusic');
	        // youwin = game.add.audio('youwin');
	        bgmusic.play('',0,1,true);
	        this.loopAudio(49000);
			
			coins = game.add.group();
			coins.enableBody = true;
			
			var coin = coins.create(80,350,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(140,350,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(200,350,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(260,350,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(320,350,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;

			
			var coin = coins.create(20,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(80,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(140,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(200,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(260,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			
			
			var coin = coins.create(330,220,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(330,220,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(390,220,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(450,220,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;	
			var coin = coins.create(510,220,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;	
			var coin = coins.create(570,220,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;


			var coin = coins.create(550,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(610,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(670,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;	
			var coin = coins.create(730,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(790,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;	
			var coin = coins.create(850,70,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;	
			
			var coin = coins.create(530,350,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(590,350,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(650,350,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;	
			var coin = coins.create(710,350,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;
			var coin = coins.create(770,350,'coin');
			coin.body.gravity.y = 1000 + Math.random()* 1.5;	
			

		
			
			this.time.advancedTiming = true;
	        this._timeCounter = 0;
	        this._leftTime = 30;    
	        this._leftTimeText = this.add.text(50, 50, 'Time: 30', { fontSize: '28px', fill: '#cc3399' });
			
	        



			button = game.add.button(650,450,"button",this.lundagNaruto);
		   	button1 = game.add.button(50,450,"button1",this.kananNaruto);
		   	button2 = game.add.button(250,445,"button2",this.kaliwaNaruto);
		   
			player = game.add.sprite(32,game.world.height -150,'dude');
			player.scale.x = 1.5;
			player.scale.y = 1.5;

			
			game.physics.arcade.enable(player);

			game.physics.arcade.enable(platforms);
			
			player.body.bounce.y = 0.2;
			player.body.gravity.y = 800;
			//player.body.gravity.x = 15000;
			player.body.collideWorldBounds = true;
			
			player.animations.add('left',[4,5,6,7],10,true);
			player.animations.add('right',[8,9,10,11],10,true);
			
			player.animations.add('left',[0,1,2,3],10,true);
			player.animations.add('right',[5,6,7,8],10,true);
			player.body.velocity.x =0;

			enemy = game.add.sprite(70,370,"enemy");
			enemy.animations.add('left', [0,1,2,3], 10, true);
			enemy.animations.add('right', [5,6,7,8], 10, true);
			enemy.scale.x=1;
			enemy.scale.y=1;
			game.physics.arcade.enable(enemy);
			enemy.body.collideWorldBounds = true;

			enemy1 = game.add.sprite(0,100,"enemy1");
			enemy1.animations.add('left', [0,1,2,3], 10, true);
			enemy1.animations.add('right', [5,6,7,8], 10, true);
			enemy1.scale.x=1;
			enemy1.scale.y=1;
			game.physics.arcade.enable(enemy1);
			enemy1.body.collideWorldBounds = true;

			enemy2 = game.add.sprite(1600,400,"enemy2");
			enemy2.animations.add('left', [0,1,2,3], 10, true);
			enemy2.animations.add('right', [5,6,7,8], 10, true);
			enemy2.scale.x=1;
			enemy2.scale.y=1;
			game.physics.arcade.enable(enemy2);
			enemy2.body.collideWorldBounds = true;

			enemy3 = game.add.sprite(290,220,"enemy3");
			enemy3.animations.add('left', [0,1,2,3], 10, true);
			enemy3.animations.add('right', [5,6,7,8], 10, true);
			enemy3.scale.x=1;
			enemy3.scale.y=1;
			game.physics.arcade.enable(enemy3);
			enemy3.body.collideWorldBounds = true;

			enemy4 = game.add.sprite(530,85,"enemy4");
			enemy4.animations.add('left', [0,1,2,3], 10, true);
			enemy4.animations.add('right', [5,6,7,8], 10, true);
			enemy4.scale.x=1;
			enemy4.scale.y=1;
			game.physics.arcade.enable(enemy4);
			enemy4.body.collideWorldBounds = true;

			
			
		

			

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 0.5,this.enemyMoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 0.5,this.enemyMoveLeft);
			
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy1MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy1MoveLeft);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy2MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy2MoveLeft);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy3MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy3MoveLeft);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy4MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy4MoveLeft);

			
		
			
			bestScoreText = game.add.text(570,20,"BestScore: "+playGame.getScore(),{fill:'#cc3399'});
			bestScoreText.fixedToCamera = true;
			scoreText = game.add.text(50,20,"SCORE: 0",{fill:'#cc3399'});
			scoreText.fixedToCamera = true;
			
			

			
			
			game.camera.follow(player,Phaser.Camera.FOLLOW_TOPDOWN);
			
			button.fixedToCamera = true;
			button1.fixedToCamera = true;
			button2.fixedToCamera = true;
			this._leftTimeText.fixedToCamera = true;
			
			
		
			

			
	},
	
	
	update: function () {
			game.physics.arcade.collide(player,platforms,0,0);
			game.physics.arcade.collide(player,platformers,0,0);
			game.physics.arcade.collide(platforms,coins);
			game.physics.arcade.collide(platformers, coins);
			game.physics.arcade.overlap(player,coins,this.killcoins);
			game.physics.arcade.overlap(player,enemy,this.killPlayerr);
			game.physics.arcade.overlap(player,enemy1,this.killPlayerr);
			game.physics.arcade.overlap(player,enemy2,this.killPlayerr);
			game.physics.arcade.overlap(player,enemy3,this.killPlayerr);
			game.physics.arcade.overlap(player,enemy4,this.killPlayerr);
			game.physics.arcade.overlap(player,enemy5,this.killPlayerr);
			game.physics.arcade.overlap(player,enemy6,this.killPlayerr);
			game.physics.arcade.overlap(player,enemy7,this.killPlayerr);



			
		    if(keyboard.left.isDown){
				player.body.velocity.x = -300;
		        player.animations.play('left');
		       
		        // bg.frame = 0;
		    }
		    else if(keyboard.right.isDown){
		        // bg.frame = 1;
		        player.animations.play('right');
		        player.body.velocity.x = 300;
		    }
		    else{
		        player.body.velocity.x = 0;
		        player.animations.stop();
		    }

		    if(keyboard.up.isDown && player.body.touching.down){
		        player.body.velocity.y = -500;
		    }
			 // update timer every frame
	        this._timeCounter += this.time.elapsed;
	        // if spawn timer reach one second (1000 miliseconds)
	        if(this._timeCounter > 1000) {
	            // reset it
	            this._timeCounter = 0;
	            this._leftTime --;
	            this._leftTimeText.text = 'Time: ' + this._leftTime;
	        }
	        
	        if(this._leftTime <= 0) {      
	            // this.quitGame();
				

	        gameover = game.add.button(0,0, 'tiu',this.gameOver1);
			
	        var pausedText = game.add.text(250, 360, "Tap anywhere to Menu.", { fontSize: '28px', fill: '#FFF' });
							pausedText.fixedToCamera = true;
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            //window.location.href=window.location.href;
					            
					        }, this);
					    }
				
	
			
		},
	
        killcoins:function(player,coins){
            score = score + 1;
            scoreText.text = "SCORE:"+ score;
            coins.kill();
			
            
        	
            if(playGame.getScore()<=score){
                saveScore(score);
                bestScoreText.text = "bestscore: "+score;
            }
        },

        

			
            loopAudio:function (time){
			    setInterval(function(){
			        bgmusic.play();
			    },time);
			},
    		gameOver:function (){
			       window.location.href=window.location.href;

			},
    		gameOver1:function (){
			       window.location.href=window.location.href;

			},
			gameOver2:function (){
			       window.location.href=window.location.href;

			},




	


          enemyMoveRight:function() {
    
        			this.enemy.body.velocity.x = -320;
					this.enemy.animations.play('right');

          },
          enemyMoveLeft:function() {
            
        			this.enemy.body.velocity.x = 320;
					this.enemy.animations.play('left');

          },

          enemy1MoveLeft:function() {
            
        			this.enemy1.body.velocity.x = 320;
					this.enemy1.animations.play('right');

          },

          enemy1MoveRight:function() {
    
        			this.enemy1.body.velocity.x = -320;
					this.enemy1.animations.play('left');

          },
          enemy2MoveLeft:function() {
    
        			this.enemy2.body.velocity.x = -320;
					this.enemy2.animations.play('left');

          },

          enemy2MoveRight:function() {
    
        			this.enemy2.body.velocity.x = 320;
					this.enemy2.animations.play('right');

          },
          enemy3MoveLeft:function() {
            
        			this.enemy3.body.velocity.x = -320;
					this.enemy3.animations.play('left');

          },

          enemy3MoveRight:function() {
    
        			this.enemy3.body.velocity.x = 320;
					this.enemy3.animations.play('right');

          },

          enemy4MoveLeft:function() {
    
        			this.enemy4.body.velocity.x = -320;
					this.enemy4.animations.play('left');

          },

          enemy4MoveRight:function() {
    
				  this.enemy4.body.velocity.x = 320;
				  this.enemy4.animations.play('right');

          },


          killPlayerr:function(player,enemy){
				player.kill();
          		gameover = game.add.button(0,0, 'gameover1',this.gameOver2);
                	player.kill();
					
                	var pausedText = game.add.text(250, 360, "Go back in Menu.", { fontSize: '28px', fill: '#FFF' });
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            window.location.href=window.location.href;
					            
					        }, this);
					    

          },

          killPlayerr:function(player,enemy1){
          		player.kill();
				
				gameover = game.add.button(0,0, 'gameover1',this.gameOver2);
                	player.kill();
                	var pausedText = game.add.text(250, 360, "Go back in Menu.", { fontSize: '28px', fill: '#FFF' });
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            window.location.href=window.location.href;
					            
					        }, this);
					    
          },
          killPlayerr:function(player,enemy2){
          		player.kill();
				
				gameover = game.add.button(0,0, 'gameover1',this.gameOver2);
                	player.kill();
                	var pausedText = game.add.text(250, 360, "Go back in Menu.", { fontSize: '28px', fill: '#FFF' });
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            window.location.href=window.location.href;
					            
					        }, this);
					      
          },

          killPlayerr:function(player,enemy3){
				player.kill();
				
          		 
				
				gameover = game.add.button(0,0, 'gameover1',this.gameOver2);
                	player.kill();
                	var pausedText = game.add.text(250, 360, "Go back in Menu.", { fontSize: '28px', fill: '#FFF' });
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            window.location.href=window.location.href;
					            
					        }, this);
					    
          },
          killPlayerr:function(player,enemy4){
          		player.kill();
				
				gameover = game.add.button(0,0, 'gameover1',this.gameOver2);
                	player.kill();
                	var pausedText = game.add.text(250, 360, "Go back in Menu.", { fontSize: '28px', fill: '#FFF' });
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            window.location.href=window.location.href;
					            
					        }, this);
					     
          },

          killPlayerr:function(player,enemy5){
				player.kill();
				
          		gameover = game.add.button(0,0, 'gameover1',this.gameOver2);
                	player.kill();
                	var pausedText = game.add.text(250, 360, "Go back in Menu.", { fontSize: '28px', fill: '#FFF' });
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            window.location.href=window.location.href;
					            
					        }, this);
					    
          },
          killPlayerr:function(player,enemy6){
				player.kill();
				
          		gameover = game.add.button(0,0, 'gameover1',this.gameOver2);
                	player.kill();
                	var pausedText = game.add.text(250, 360, "Go back in Menu.", { fontSize: '28px', fill: '#FFF' });
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            window.location.href=window.location.href;
					            
					        }, this);
					      
          },

          killPlayerr:function(player,enemy7){
				player.kill();
				
          		gameover = game.add.button(0,0, 'gameover1',this.gameOver2);
                	player.kill();
                	var pausedText = game.add.text(250, 360, "Go back in Menu.", { fontSize: '28px', fill: '#FFF' });
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            window.location.href=window.location.href;
					            
					        }, this);
					    
          },



          lundagNaruto:function(){
              button.frame = 1;
			 
              if(player.body.touching.down){

                  player.body.velocity.y = -500;
              }

              setTimeout(function(){
                  button.frame = 0;
              },300)
          },


          kananNaruto:function(){
              button1.frame = 1;
			 
			
			
              player.body.velocity.x = -2500;
              player.animations.add('left',[0,1,2,3,4],10,true);
               	
            setTimeout(function(){
                	
              player.animations.play('left');

              button1.frame = 0;
            },300)
          },


          kaliwaNaruto:function(){
              button2.frame = 1;
			 
              //	if(keyboard.right.isDown){
              	player.animations.add('right',[5,6,7,8],10,true);
             		player.body.velocity.x = 2500;
             	//	}
              setTimeout(function(){
          		    player.animations.play('right');

                  button2.frame = 0;
                 },100)
          },


         /* tigilTuloy:function(){
              setTimeout(function(){
                  btn.frame = 1;
                  game._paused = false;
			btn.fixedToCamera = true;
              },3000)
              	btn.frame = 0;

              game._paused =true;
          },   */		








            getScore:function(){
                return (localStorage.getItem("gameData") == null || localStorage.getItem("gameData") == "")?0:localStorage.getItem("gameData");
            },

            saveScore:function(score){
                localStorage.setItem("gameData",score);
            },



            restart:function (){
                window.location.href=window.location.href;
                stateText.visible = false;
            }
        
}
