winGame = {
	create:function(){
		
		
	},
	update:function(){
	}
}