preloadGame = {
	preload :function() {

			game.load.image('sky','img/sky.png');
			game.load.image('ground','img/lapag.png');
			game.load.image('grounded','img/sahig.png');
			game.load.image('bg','img/bgdesign.png');
			game.load.image('coin','img/qqq.png');
			game.load.image('fire','img/fire.png');

			game.load.spritesheet('explode','img/explode.png',150,128);
			game.load.spritesheet('dude','img/dude.png',32,48);
			game.load.spritesheet("button","img/btn-jump.png",100,100);
			game.load.spritesheet("button1","img/btn-left.png",100,100);
			game.load.spritesheet("button2","img/btn-right.png",100,100);
			//game.load.spritesheet("pause","img/tigil.png",100,100);

			//game.load.image('btn', 'img/qwe.png');
		    game.load.image('title','img/menu.png',800,600);
			game.load.image('start','img/starts.png');
			game.load.image('about','img/btn-about.png');
			game.load.image('back2','img/back.png');
			
			game.load.image('btn_paused', 'img/pause2.png');
			game.load.image('btn_pause', 'img/pause.png');
			
			
			game.load.image('gameover1','img/una.png');
			game.load.image('tiu','img/tgame.png');

			game.load.spritesheet('enemy', 'img/1.png', 32, 48);
			game.load.spritesheet('enemy1', 'img/1.png', 32, 48);
			game.load.spritesheet('enemy2', 'img/1.png', 32, 48);
			game.load.spritesheet('enemy3', 'img/1.png', 32, 48);
			game.load.spritesheet('enemy4', 'img/1.png', 32, 48);
			

			game.load.audio("bgmusic","audio/wes.mp3");
			
			
	},
	create:function(){
			game.state.start('menuGame');
	},
}