
var w = 800,h = 600;
var platforms,platformers,player,keyboard,score,score = 0, bestScore,getScore,Fires,coins,gameOverText,scoreText,fire, lifeText, life = 1,bestScoreText,shineDiamond,shineDiamonds,explodeFire,btn, timeText,time;
//var boundsRight = 1600;
var duration=60;
var titlepage;
var startButton;
var players , tiu,gameOver1;
var x = 0;
var restart;
	this.time;      //  the clock (Phaser.Time)
    this.game;      //  a reference to the currently running game (Phaser.Game)
    var paused;
	this._timeCounter = null;
	this._leftTime = null;
	this._leftTimeText = null;
	var timesup_title = null;
var winGame, playGame;
var time=1000;
var actionOnClick,btn_pause;
var enemy,enemy1,enemy2,enemy3,enemy4,enemy5,enemy6,enemy7;
var killcoins, killPlayerr;
var duration;
var player, keyboard;
var updateTime;
var lundagNaruto,kananNaruto,kaliwaNaruto,tigilTuloy;
var enemyMoveRight,enemyMoveLeft,enemy1MoveRight,enemy1MoveLeft,enemy2MoveRight,enemy2MoveLeft,enemy3MoveRight,enemy3MoveLeft,enemy4MoveRight,enemy4MoveLeft,enemy5MoveRight,enemy5MoveLeft,enemy6MoveRight,enemy6MoveLeft,enemy7MoveDown,enemy7MoveUp;

var game = new Phaser.Game(800, 600, Phaser.CANVAS, '');

game.state.add('bootGame', bootGame);
game.state.add('preloadGame', preloadGame);
game.state.add('menuGame', menuGame);
game.state.add('playGame', playGame);
game.state.add('winGame', winGame);
//game.state.add('helpGame', helpGame);
game.state.add('aboutGame', aboutGame);

game.state.start('bootGame');